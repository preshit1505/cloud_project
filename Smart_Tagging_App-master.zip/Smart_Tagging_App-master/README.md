# Smart_Tagging_App


Smart-Tagging is an nfc based android application, with cloud synchronization
Technologies Used: Android SDK, Firebase
Firebase is a database service provided by google app engine, which is of NoSQL data

To start Using this app goto Firebase.com create your own app in firebase and donot add any records,
then goto to the app in android studio and goto AdminLoginActivity,
add your firebase url in db_url variable
Do the same in AdminSignUpActivity and add your firebase url in db_url variable

Then you are done, install the app in your phone via android studio and start creating users and login and explore all the options.
